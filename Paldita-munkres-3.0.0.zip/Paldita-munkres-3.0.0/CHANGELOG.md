# Change Log, munkres.py

Version 3.0.0 (stable release)

**Audit fixes**

- Fixed: `longdouble` input no longer rounded to float64 on the NumPy path (lossy arrays use the exact solver).
- Fixed: `solve_batch` never narrows dtypes (large int64/uint64, lossy longdouble and object scalars are exact; native int64 kernel where safe); `maximize=True` fallback solved the wrong objective; `on_infeasible` validated; failed problems return `-1` rows.
- Fixed: `gibbs`/`gibbs_sample` run in log space (no false "unsolvable" from underflow) and validate `beta`.
- Fixed: `regret_of` validates complete assignments and `low <= high`.
- Fixed: fingerprinting, planning, hashing and structure helpers handle huge ints/Fractions and `Decimal('Infinity')` through one shared forbidden-cell predicate.
- Fixed: `AssignmentState` mutators are transactional; `update_costs` is all-or-nothing; unknown `remove_column` raises `KeyError`; `snapshot`/`restore` carry the operation log; deterministic tie-breaking.
- Fixed: `stable_matching` accepts `None` as a participant name; `tools/verify_package.py` has real checks.
- Changed: native kernel ABI 2 (allocation-free core, one workspace per batch, strict buffer validation, `lsa` ndarray entry point: ~2.3x lower per-call overhead on tiny matrices).
- Added: production safety layer: load-time kernel self-test, per-call soft fallback to the exact Python solver, circuit breaker, `native_status()`, `reset_native()`, `set_strict_mode()`, `PALDITA_STRICT` (see docs/production.md).
- Added: `min_weight_full_bipartite_matching(biadjacency_matrix, maximize=False)` with the SciPy sparse-matching signature.
- Added: Meson build (`meson.build`, `meson.options`, `pyproject.meson.toml`, `tools/build_meson.sh`, `.github/workflows/meson.yml`) alongside setuptools; optional native extension; drift-guard tests in `tests/test_meson_build.py`.
- Added: `tools/fuzz_native.py`, `tools/sanitize_native.sh` (ASan+UBSan), `tests/v3/test_audit_fixes.py`, AST hygiene test.

**Fixed**

- Float costs near the float range no longer raise a false `UnsolvableMatrix` (the solver now switches to exact arithmetic).
- `make_cost_matrix` accepts `Decimal('Infinity')`.

**Hardened** (found by the new `tests/hard` suite)

- `Certificate.from_json` and `solve_spec` raise only `ValueError` for malformed input; the `certify` command handles an empty matrix; backend descriptors list every dtype they really support.

**New**

- Optional native C kernel (`munkres._lapc`, built if a compiler is available; pure-Python fallback otherwise), `solve_batch`, `AssignmentSolver`.
- Exact certificates and an independent verifier (`certify`, `verify_pairs`, `problem_hash`); CLI `doctor`, `inspect`, `certify`, `verify`.
- Structure and analysis: `fingerprint`, Monge witnesses, `plan` / `solve_planned`, `components`, `topology`, `edge_margins`, `enumerate_optima`, `canonical_optimum`, `exchange_cycles`, `reduce_costs`, `dulmage_mendelsohn`, `gibbs`, `count_matchings`, `regret_of`.
- Second batch: sensitivity/landscape tools, `parametric_assignment`, tropical and closed-form solvers, `market_equilibrium`, scenario tools, `solve_with_bound`, `prune_edges_by_bound`, `qap_lower_bound`, exact `gibbs_sample`, `CertificateCache`, `check_equivalent`, `profile_solve`, `backends`, `versions`, event log replay.
- Third batch: determinant-based matching, `popular_matching`, energy landscape/barriers, `cvar_assignment`, `solve_3d`, `solve_lazy` / `solve_points` (exact, no dense matrix).
- `AssignmentState` (dynamic repair), `assign_with_inertia`, `TemporalAssignment`, `rank_maximal`.
- See `docs/V3_ARCHITECTURE.md` for the design.

Version 2.0.0 (stable release)

A ground-up modernisation. See also `V2_RELEASE.txt`. Modified from munkres 1.1.4 by
Brian M. Clapper (Apache License 2.0); the changes below were made by Eishit Nigam.

**New**

- `solve()` returns an `Assignment` (pairs, total, unmatched rows/columns, pandas labels) and
  supports `maximize=True`, gating (`max_cost` / `min_profit`) and `trace=True` (a step-by-step
  `Trace`, as text or a static HTML page).
- `diagnose()` explains why a matrix has no complete assignment; `linear_sum_assignment()` is a
  SciPy-compatible drop-in; `build_cost_matrix()` builds a matrix from two lists and a cost function.
- Analysis: `shadow_prices` (LP duals, an optimality certificate), `counterfactual`, `tolerance`,
  `k_best` (Murty's algorithm), `bottleneck`.
- Related problems: `stable_matching` (Gale-Shapley), `transport` (transportation problem),
  `sinkhorn` / `soft_assignment` (entropic optimal transport).
- A command line tool, `munkres costs.csv --maximize --json --trace`, and `python -m munkres`
  (a built-in self-check).
- Accepts tuples, numpy arrays and pandas DataFrames; works with `int`, `float`, `Fraction` and
  `Decimal` costs and integers of any size.
- Type hints are exported (`py.typed`); `mypy --strict` clean.

**Changed**

- Python 3.10 or newer is required.
- The solver is a shortest-augmenting-path Hungarian implementation with dual potentials and a warm
  start: O(n^2 * m), about 5x to 50x faster than 1.1.4 on random matrices and on par when almost all costs
  tie (see `docs/BENCHMARKS.md`).
- Ragged (non-rectangular) matrices raise `ValueError`; empty matrices return an empty result.
- `NaN` and `-inf` costs raise `ValueError`; `+inf` means "forbidden", like `DISALLOWED`.
- Non-numeric cells raise `TypeError`.
- `UnsolvableMatrix` derives from `ValueError` and carries `rows` / `cols` (the rows that compete for
  too few columns).
- Packaging moved from `setup.py` / `setup.cfg` to `pyproject.toml`; the code lives in `src/munkres/`.
  The wheel is tagged `py3`, and `python_requires` is declared.
- `__all__` now exports `UnsolvableMatrix`, `print_matrix` and the new API.

**Fixed**

- Matrices whose `DISALLOWED` cells make an assignment impossible no longer wait forever:
  `UnsolvableMatrix` is raised immediately.
- `NaN`, `-inf` and all-infinite rows no longer hang the solver.
- Rectangular and ragged input no longer returns pairs that do not exist in the matrix or drops columns.
- numpy input is no longer modified in place; rectangular numpy arrays and tuples work.
- Empty input no longer raises `IndexError`.
- One `Munkres` object can be shared between threads (it holds no state).
- Integers larger than `sys.maxsize` are handled correctly.
- `make_cost_matrix()` accepts matrices containing `DISALLOWED`; `DISALLOWED` survives `copy`,
  `deepcopy` and `pickle`.
- Documentation no longer refers to a method that does not exist.

**Project**

- Test-suite: regression, property-based (Hypothesis) and randomised tests checked against independent
  oracles (exhaustive search, SciPy), 100 % line and branch coverage.
- GitHub Actions: tests on Python 3.10-3.14 (Linux, plus Windows and macOS), CodeQL, dependency review,
  security scans, docs, benchmarks and nightly runs; releases use PyPI trusted publishing.
- `tools/audit.sh` runs lint, formatting, spelling, `mypy --strict`, bandit, a secrets scan, coverage,
  docs build, packaging checks and a clean-install smoke test.

Version 1.1.4 (September, 2020)

- Switched from Nose to Pytest for testing. Patch courtesy @kmosiejczuk,
  [PR #32](https://github.com/bmc/munkres/pull/32), with some additional
  cleanup by me.
- Fix to [Issue #34](https://github.com/bmc/munkres/issues/34), in which
  `print_matrix` wasn't handling non-integral values. Patch courtesy @finn0,
  via [PR #35](https://github.com/bmc/munkres/pull/35).
- Various changes from `http:` URLs to `https:` URLs, courtesy @finn0
  via [PR #36](https://github.com/bmc/munkres/pull/36/).

Version 1.1.3:

**Nonexistent**. Accidentally published before check-in. Deleted from
PyPI. Use version 1.1.4.

Version 1.1.2 (February, 2019)

- Removed `NoReturn` type annotations, to allow compatibility with Python 3.5 
  releases prior to 3.5.4. Thanks to @jackwilsdon for catching that issue.

Version 1.1.1 (February, 2019)

- Version bump to get past a PyPI publishing issue. (Can't republish
  partially published 1.1.0.)

Version 1.1.0 (February, 2019)

- Only supports Python 3.5 or better, from this version forward (since Python
  2 is at end of life in 11 months).
- Added `typing` type hints.
- Updated docs to use `pdoc`, since `epydoc` is pretty much dead.

Version 1.0.12 (June, 2017)

- Merged [Pull Request #11](https://github.com/bmc/munkres/pull/11), from
  [@brunokim](https://github.com/brunokim), which simplifies conversion of a 
  profit matrix to a cost matrix, in the default case.
  
- Merged [Pull Request #7](https://github.com/bmc/munkres/pull/7), from
  [@mdxs](https://github.com/mdxs), which fixes a message.
  
- Added more tests.

Version 1.0.11 (June, 2017)

- Docs are now generated with [pdoc](https://github.com/BurntSushi/pdoc).

- Merged [Pull Request 24](https://github.com/bmc/munkres/pull/24), from
  [@czlee](https://github.com/czlee): 
    - Change to step 4: When it looks for a uncovered zero, rather than starting 
      at row 0, column 0, it starts where it left off, i.e. at the last 
      uncovered zero it found. Since it doesn't start at (0,0), when it gets to 
      the last column it now loops around to the first, and exits unsuccessfully 
      if it got back to where it started. This change reduces this reduces the 
      solving time for (certain) large matrices. For instance, in tests, 
      solving a matrix of size 394×394  goes from about 2 minutes to about 4 
      seconds.
    - Since Python 3 started cracking down on unnatural comparisons, the 
      `DISALLOWED` constant added in 
      [Pull Request 19](https://github.com/bmc/munkres/issues/19) no longer 
      works. (It raises a TypeError for unorderable types, as is expected in 
      Python 3.) Since this constant is meant to act like infinity, this 
      modification just changes the two lines where it would otherwise try to 
      make an illegal (in Python 3) comparison between a number and 
      `DISALLOWED_OBJ()` and gets it to behave as if `DISALLOWED` is always 
      larger.

- Added Travis CI integration.

- Added some unit tests. See `tests` and `tests/README.md`.

Version 1.0.10 (May, 2017)

- Updated `setup.py` to produce a wheel.

Version 1.0.9 (Jan, 2017)

- Fixed URL to original implementation. Addresses
  [Issue #4](https://github.com/bmc/munkres/issues/4).
- Fixes from [@kylemcdonald](https://github.com/kylemcdonald):
    - `print_matrix()` no longer crashes on 0. Fixes
      [Issue #1](https://github.com/bmc/munkres/issues/4).
    - Fixed bug where step 3 could quit early. Fixes 
      [Issue #16](https://github.com/bmc/munkres/issues/16).
    - Added step 2 break for a small optimization.
    - Added time bound to README. Addresses 
      [Issue #15](https://github.com/bmc/munkres/issues/15).
- Versioning will now adhere to
  [semantic version specification](https://semver.org).

Version 1.0.8 (June, 2016)

- License is now ASL.

Version 1.0.7 (December, 2014)

Fix from Stephan Porz (s.porz /at/ uni-bonn.de):
- Fix pad_matrix: pad_value now actually used

Version 1.0.6 (December, 2013)

Fixes from Markus Padourek (markus.padourek /at/ gmail.com):
- sys.maxsize fix and bump to 1.0.6
- Updated to Python 3.x 

Version 1.0.5.3 (2 August, 2009)

- Fixed documentation of print_matrix() in module docs.

Version 1.0.5.2 (30 June, 2008):

- Incorporated some suggestions optimizations from Mark Summerfield
  (mark /at/ qtrac.eu)
- Munkres.make_cost_matrix() is now deprecated, in favor of a module-level
  function.
- The module now provides a print_matrix() convenience function.
- Fixed some bugs related to the padding of non-square matrices.

Version 1.0.5.1 (26 June, 2008)

- Some minor doc changes.

Version 1.0.5 (26 June, 2008)

- Now handles non-square cost matrices by padding them with zeros.
- Converted Epydocs to use reStructuredText.

Version 1.0.4 (13 June, 2008)

- Minor bug fix in main (tester) program in munkres.py

Version 1.0.3 (16 March, 2008)

- Minor change to prevent shadowing of built-in min() function. Thanks to
  Nelson Castillo (nelson /at/ emqbit.com) for pointing it out.

Version 1.0.2 (21 February, 2008)

- Fixed an overindexing bug reported by Chris Willmore (willmc <at> rpi.edu)

Version 1.0.1 (16 February, 2008)

- Documentation now processed by Epydoc.

Version 1.0 (January, 2008)

- Initial release.
